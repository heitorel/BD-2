package com.bd.climed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClimedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClimedApplication.class, args);
	}


	// https://www.youtube.com/watch?v=8D5BS1NbHPM&list=PLWXw8Gu52TRI0usqoSTLrioF6NPp-3msb

}
