package com.bd.climed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClimedApplicationTests {

	@Test
	void contextLoads() {
	}

}
